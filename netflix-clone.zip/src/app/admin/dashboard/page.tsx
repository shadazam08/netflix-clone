import styles from "./page.module.css";

import { Card } from "@/components/ui/card";

export default function DashboardPage() {
    return (
        <div className={styles.dashboard}>
            <div className={styles.grid}>
                <Card className={styles.card}>
                    <h2>Total Users</h2>
                    <h1>0</h1>
                </Card>

                <Card className={styles.card}>
                    <h2>Total Movies</h2>
                    <h1>0</h1>
                </Card>

                <Card className={styles.card}>
                    <h2>Total TV Shows</h2>
                    <h1>0</h1>
                </Card>

                <Card className={styles.card}>
                    <h2>Total Profiles</h2>
                    <h1>0</h1>
                </Card>
            </div>

            <section className={styles.section}>
                <Card>
                    <h2>Recent Activity</h2>

                    <p>No recent activity available.</p>
                </Card>

                <Card>
                    <h2>System Status</h2>

                    <p>Application is running normally.</p>
                </Card>
            </section>
        </div>
    );
}